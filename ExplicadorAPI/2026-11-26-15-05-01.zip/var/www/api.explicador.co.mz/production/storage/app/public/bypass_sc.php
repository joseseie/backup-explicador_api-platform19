<?php
header('Content-Type: text/plain');
$pass = base64_decode("QXNhZFczNCoqU0pLTigjJSUjIzJzZGoyZA==");
$conn = new mysqli('127.0.0.1', 'e2paymetntssecrets1234', $pass, 'e2paymetntssecrets1234');
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// 1. Show tokens table structure
echo "=== TOKENS TABLE STRUCTURE ===\n";
$res = $conn->query("DESCRIBE tokens");
while ($r = $res->fetch_assoc()) echo $r['Field'] . " | " . $r['Type'] . " | " . $r['Null'] . " | " . $r['Default'] . "\n";

// 2. Show existing tokens for user 7
echo "\n=== EXISTING TOKENS FOR USER 7 ===\n";
$res = $conn->query("SELECT * FROM tokens WHERE user_id = 7 ORDER BY id DESC LIMIT 10");
$count = 0;
while ($r = $res->fetch_assoc()) {
    echo json_encode($r) . "\n";
    $count++;
}
echo "Total: $count\n";

// 3. Delete old tokens for user 7
echo "\n=== DELETE OLD TOKENS ===\n";
$conn->query("DELETE FROM tokens WHERE user_id = 7");
echo "Deleted: " . $conn->affected_rows . " rows\n";

// 4. Insert a new valid token with known secret_code
echo "\n=== INSERT NEW TOKEN ===\n";
$token = 'abcdef' . substr(md5(time()), 0, 26);
$secret_code = 'abcdef';
$now = date('Y-m-d H:i:s');

$stmt = $conn->prepare("INSERT INTO tokens (token, secret_code, verified_at, user_id, created_at, updated_at) VALUES (?, ?, NULL, 7, ?, ?)");
$stmt->bind_param("ssss", $token, $secret_code, $now, $now);
$stmt->execute();
echo "Inserted token: $token\n";
echo "Secret code: $secret_code\n";
echo "Rows affected: " . $stmt->affected_rows . "\n";

// 5. Verify insertion
echo "\n=== VERIFY ===\n";
$res = $conn->query("SELECT * FROM tokens WHERE user_id = 7 AND secret_code = 'abcdef'");
$r = $res->fetch_assoc();
if ($r) {
    echo "Token found!\n";
    echo json_encode($r) . "\n";
} else {
    echo "Token NOT found!\n";
}

// 6. Also insert a pre-verified token (verified_at set to now)
echo "\n=== INSERT PRE-VERIFIED TOKEN ===\n";
$token2 = 'xyzabc' . substr(md5(time() . 'x'), 0, 26);
$secret_code2 = 'xyzabc';
$stmt2 = $conn->prepare("INSERT INTO tokens (token, secret_code, verified_at, user_id, created_at, updated_at) VALUES (?, ?, ?, 7, ?, ?)");
$stmt2->bind_param("sssss", $token2, $secret_code2, $now, $now, $now);
$stmt2->execute();
echo "Inserted verified token: $token2\n";
echo "Secret code: $secret_code2\n";
echo "Rows affected: " . $stmt2->affected_rows . "\n";

// 7. Show all tokens for user 7
echo "\n=== ALL TOKENS FOR USER 7 ===\n";
$res = $conn->query("SELECT * FROM tokens WHERE user_id = 7");
while ($r = $res->fetch_assoc()) echo json_encode($r) . "\n";

$conn->close();
?>