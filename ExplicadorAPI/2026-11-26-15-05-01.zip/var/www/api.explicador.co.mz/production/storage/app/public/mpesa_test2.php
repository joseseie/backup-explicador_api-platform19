<?php
// Using correct Karson SDK token generation logic
$api_key = "kkywztycbmz55enw5ykmb6kawwybotqm";
$public_key_b64 = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEArv9yxA69XQKBo24BaF/D+fvlqmGdYjqLQ5WtNBb5nquFo2+hVR66bt87oVCl5bESYQQq7VhoEJY3EGbcM0CiLJXLCoGODX97MJMOkHaGGMFXoUMG/JdCV03RmzKkODCkCfKkW3SR3TxrE7GnI3r7F9Xt7FitbuTMQ3mClR0VsDBiEQ4URLIBtJnBvH8DjPANFcJW5Vey4z7DTtGSJ4yCc8e2AHxS7JxpGKONT8OVVljG/5fjIPDHOJNNiI2x48IxDnVIFbntDqkPDNojbwQTpiNwU6bFjVL1HDTHG4gUBfNjxBR6OBLoAmHhHSHCPJRo0meG4OD2MVhaiF3IWhtPWF2Jv5fRkb/Y6LjteQ/RsUap0bgaFGYJzIPOuCXB0EHsGBiuDFE/lPbRIaBfB6T2DYaSBFdFxgYDj/AeU+amPMR98vMX3uR4XM2X0boRFE4TH1mcsAPf/ND1XxE9eClmrBuLYy52PH2Q2VGqWrN26/M9PoVwOIIfO4v2bKgVF3vSYgqZyDB7L0thIj57MBEAvu0lX+Set2VWkwneJG2RSt+K63oeVbwTOCQq2X9PAInMa+8R7Vx1niNbMzU3dMEhFd3rKKPnPP3GKMQP3fCWdNknJLENZKGfepNEMCB5P9TCSj+8C8LmScyaZkv3hZG717EMWb4idOknp+pWwRIk4/kCAwEAAQ==";

// Exact Karson SDK logic
$pk = wordwrap($public_key_b64, 60, "\n", true);
$pk = "-----BEGIN PUBLIC KEY-----\n" . $pk . "\n-----END PUBLIC KEY-----";
$encrypted = '';
$result = openssl_public_encrypt($api_key, $encrypted, $pk, OPENSSL_PKCS1_PADDING);
$token = base64_encode($encrypted);

echo "KEY=" . $api_key . "\n";
echo "SPC=900283\n";
echo "TK_LEN=" . strlen($token) . "\n";
echo "TK_B64=" . substr($token, 0, 50) . "...\n";

// Test C2B with this token (SPC 900283)
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.vm.co.mz:18352/ipg/v1x/c2bPayment/singleStage/");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Origin: developer.mpesa.vm.co.mz",
    "Authorization: Bearer " . $token
]);

$data = json_encode([
    "input_TransactionReference" => "T12345TEST",
    "input_CustomerMSISDN" => "258840000000",
    "input_Amount" => "1",
    "input_ThirdPartyReference" => "TEST_REF",
    "input_ServiceProviderCode" => "900283"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
echo "C2B_900283=" . $response . "\n";
echo "HTTP=" . $http_code . "\n";

// Also test B2C with this key
curl_setopt($ch, CURLOPT_URL, "https://api.vm.co.mz:18345/ipg/v1x/b2cPayment/");
$b2c_data = json_encode([
    "input_TransactionReference" => "B12345TEST",
    "input_CustomerMSISDN" => "258840000000",
    "input_Amount" => "1",
    "input_ThirdPartyReference" => "TEST_B2C",
    "input_ServiceProviderCode" => "900283"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $b2c_data);
$b2c_response = curl_exec($ch);
echo "B2C_900283=" . $b2c_response . "\n";

curl_close($ch);
?>
