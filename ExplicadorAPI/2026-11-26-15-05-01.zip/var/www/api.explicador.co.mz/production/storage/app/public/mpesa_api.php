<?php
$ak="fjqfirtu3utorwxrqmdjmtrygfvlr9r3";
$rpk="MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEArv9yxA69XQKBo24BaF/D+fvlqmGdYjqLQ5WtNBb5nquFo2+hVR66bt87oVCl5bESYQQq7VhoEJY3EGbcM0CiLJXLCoGODX97MJMOkHaGGMFXoUMG/JdCV03RmzKkODCkCfKkW3SR3TxrE7GnI3r7F9Xt7FitbuTMQ3mClR0VsDBiEQ4URLIBtJnBvH8DjPANFcJW5Vey4z7DTtGSJ4yCc8e2AHxS7JxpGKONT8OVVljG/5fjIPDHOJNNiI2x48IxDnVIFbntDqkPDNojbwQTpiNwU6bFjVL1HDTHG4gUBfNjxBR6OBLoAmHhHSHCPJRo0meG4OD2MVhaiF3IWhtPWF2Jv5fRkb/Y6LjteQ/RsUap0bgaFGYJzIPOuCXB0EHsGBiuDFE/lPbRIaBfB6T2DYaSBFdFxgYDj/AeU+amPMR98vMX3uR4XM2X0boRFE4TH1mcsAPf/ND1XxE9eClmrBuLYy52PH2Q2VGqWrN26/M9PoVwOIIfO4v2bKgVF3vSYgqZyDB7L0thIj57MBEAvu0lX+Set2VWkwneJG2RSt+K63oeVbwTOCQq2X9PAInMa+8R7Vx1niNbMzU3dMEhFd3rKKPnPP3GKMQP3fCWdNknJLENZKGfepNEMCB5P9TCSj+8C8LmScyaZkv3hZG717EMWb4idOknp+pWwRIk4/kCAwEAAQ==";
$k="-----BEGIN PUBLIC KEY-----\n".wordwrap($rpk,60,"\n",true)."\n-----END PUBLIC KEY-----";
$p=openssl_get_publickey($k);
if(!$p){echo"PK_ERR=".openssl_error_string();exit;}
openssl_public_encrypt($ak,$t,$p,OPENSSL_PKCS1_PADDING);
$b=base64_encode($t);
echo"TK_LEN=".strlen($b)."\n";

$c=curl_init("https://api.vm.co.mz:18352/ipg/v1x/c2bPayment/singleStage/");
curl_setopt_array($c,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>json_encode(["input_TransactionReference"=>"T99X","input_CustomerMSISDN"=>"258840000000","input_Amount"=>"1","input_ThirdPartyReference"=>"99TX","input_ServiceProviderCode"=>"900348"]),CURLOPT_HTTPHEADER=>["Content-Type: application/json","Authorization: Bearer ".$b,"Origin: developer.mpesa.vm.co.mz"],CURLOPT_RETURNTRANSFER=>1,CURLOPT_SSL_VERIFYPEER=>0,CURLOPT_TIMEOUT=>25]);
$r=curl_exec($c);$h=curl_getinfo($c,CURLINFO_HTTP_CODE);$e=curl_error($c);curl_close($c);
echo"C2B=$h $r $e\n";

$c2=curl_init("https://api.vm.co.mz:18345/ipg/v1x/b2cPayment/");
curl_setopt_array($c2,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>json_encode(["input_TransactionReference"=>"B99X","input_CustomerMSISDN"=>"258840000000","input_Amount"=>"1","input_ThirdPartyReference"=>"99BX","input_ServiceProviderCode"=>"900348"]),CURLOPT_HTTPHEADER=>["Content-Type: application/json","Authorization: Bearer ".$b,"Origin: developer.mpesa.vm.co.mz"],CURLOPT_RETURNTRANSFER=>1,CURLOPT_SSL_VERIFYPEER=>0,CURLOPT_TIMEOUT=>25]);
$r2=curl_exec($c2);$h2=curl_getinfo($c2,CURLINFO_HTTP_CODE);$e2=curl_error($c2);curl_close($c2);
echo"B2C=$h2 $r2 $e2\n";
?>