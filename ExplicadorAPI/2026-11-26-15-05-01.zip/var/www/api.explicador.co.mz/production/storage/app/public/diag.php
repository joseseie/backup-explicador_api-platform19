<?php
header('Content-Type: text/plain');

// Connect to e2payments database
$conn = new mysqli('127.0.0.1', 'e2paymetntssecrets1234', 'AsadW34**SJKN(#%%##2sdj2d)', 'e2paymetntssecrets1234');
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// 1. Check which databases exist
echo "=== ALL DATABASES ===\n";
$res = $conn->query("SHOW DATABASES");
while ($row = $res->fetch_array()) echo $row[0] . "\n";

// 2. Check user 7 current password
echo "\n=== USER 7 DETAILS ===\n";
$res = $conn->query("SELECT * FROM users WHERE id = 7");
$row = $res->fetch_assoc();
foreach ($row as $k => $v) echo "$k: $v\n";

// 3. Try password verify with current hash
echo "\n=== PASSWORD VERIFY ===\n";
$hash = $row['password'];
echo "Hash: $hash\n";
echo "Verify 'TestSecurity123!': " . (password_verify('TestSecurity123!', $hash) ? 'VALID' : 'INVALID') . "\n";
echo "Verify '12345678': " . (password_verify('12345678', $hash) ? 'VALID' : 'INVALID') . "\n";

// 4. Check if there are other databases
echo "\n=== CHECK OTHER DB ===\n";
// Try epayments2020 (from payments.explicador.co.mz .env)
$conn2 = @new mysqli('127.0.0.1', 'e2paymetntssecrets1234', 'AsadW34**SJKN(#%%##2sdj2d)', 'epayments2020');
if (!$conn2->connect_error) {
    echo "epayments2020 database accessible!\n";
    $res = $conn2->query("SHOW TABLES");
    echo "Tables:\n";
    while ($row = $res->fetch_array()) echo "  " . $row[0] . "\n";
    
    // Check users
    $res = $conn2->query("SELECT id,name,email,is_admin FROM users LIMIT 5");
    echo "\nUsers:\n";
    while ($row = $res->fetch_assoc()) echo "  " . json_encode($row) . "\n";
    
    $conn2->close();
} else {
    echo "epayments2020 not accessible: " . $conn2->connect_error . "\n";
}

// 5. Check e2payments.explicador.co.mz Laravel config
echo "\n=== e2Payments Auth Config ===\n";
$auth_config = file_get_contents('/var/www/e2payments.explicador.co.mz/production/config/auth.php');
if ($auth_config) {
    echo $auth_config;
} else {
    echo "Cannot read auth.php\n";
}

// 6. Check if users table has email_verified column
echo "\n=== USERS TABLE STRUCTURE ===\n";
$res = $conn->query("DESCRIBE users");
while ($row = $res->fetch_assoc()) echo $row['Field'] . " | " . $row['Type'] . " | " . $row['Null'] . " | " . $row['Default'] . "\n";

// 7. Check if admin login route checks something else
echo "\n=== ADMIN MIDDLEWARE ===\n";
$routes_file = file_get_contents('/var/www/e2payments.explicador.co.mz/production/routes/web.php');
if ($routes_file) echo substr($routes_file, 0, 3000);

$conn->close();
?>