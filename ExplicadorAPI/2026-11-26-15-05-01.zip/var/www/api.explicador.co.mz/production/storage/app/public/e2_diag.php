<?php
error_reporting(E_ALL);
// Bootstrap e2payments application from api.explicador's execution context
// This runs under php7.2-fpm (api.explicador) but loads e2payments app
$basePath = '/var/www/e2payments.explicador.co.mz/production';
define('LARAVEL_START', microtime(true));
require $basePath . '/vendor/autoload.php';
$app = require_once $basePath . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);

// Create a request that simulates /admin
$request = Illuminate\Http\Request::create('/admin', 'GET');
$app->instance('request', $request);

// Bootstrap the application (loads config, DB, etc)
$kernel->bootstrap();

echo "Session driver: " . config('session.driver') . "
";
echo "Session lifetime: " . config('session.lifetime') . "
";
echo "Session path: " . config('session.files') . "
";

// Check auth status - simulate by loading a session
$sessionFiles = glob(config('session.files') . '/*');
echo "Session files: " . count($sessionFiles) . "
";

// Sort by mtime, newest first
usort($sessionFiles, function($a, $b) { return filemtime($b) - filemtime($a); });

foreach (array_slice($sessionFiles, 0, 3) as $file) {
    $data = @unserialize(file_get_contents($file));
    if (!$data) continue;
    
    echo "
--- Session: " . basename($file) . " ---
";
    
    $loginKey = 'login_web_' . sha1('Illuminate\Auth\SessionGuard');
    $userId = $data[$loginKey] ?? null;
    
    if ($userId) {
        echo "Authenticated as user: $userId
";
        
        // Now check hasValidToken for this user
        $sixHoursAgo = \Carbon\Carbon::now()->subHours(6)->toDateTimeString();
        $token = \App\Models\Token::where('user_id', $userId)
            ->where('verified_at', '>', $sixHoursAgo)
            ->first();
        
        if ($token) {
            echo "VALID TOKEN: sc={$token->secret_code} verified_at={$token->verified_at}
";
            echo "hasValidToken WOULD RETURN: truthy!
";
        } else {
            echo "NO VALID TOKEN!
";
            echo "Looking for all tokens for user $userId...
";
            $allTokens = \App\Models\Token::where('user_id', $userId)->get();
            echo "Total tokens: " . $allTokens->count() . "
";
            foreach ($allTokens as $t) {
                echo "  id={$t->id} sc={$t->secret_code} verified={$t->verified_at}
";
                echo "  Compare: verified_at > $sixHoursAgo ? " . ($t->verified_at > $sixHoursAgo ? 'YES' : 'NO') . "
";
            }
        }
    } else {
        echo "Not authenticated in this session
";
    }
}
?>