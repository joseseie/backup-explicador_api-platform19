<?php
header('Content-Type: text/plain');

$pass = base64_decode("QXNhZFczNCoqU0pLTigjJSUjIzJzZGoyZA==");
$conn = new mysqli('127.0.0.1', 'e2paymetntssecrets1234', $pass, 'e2paymetntssecrets1234');
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// 1. All databases
echo "=== DATABASES ===\n";
$res = $conn->query("SHOW DATABASES");
while ($r = $res->fetch_array()) echo $r[0] . "\n";

// 2. User 7 full details
echo "\n=== USER 7 ===\n";
$res = $conn->query("SELECT * FROM users WHERE id = 7");
$row = $res->fetch_assoc();
foreach ($row as $k => $v) echo "$k: $v\n";

// 3. Password verify
echo "\n=== PASSWORD VERIFY ===\n";
$hash = $row['password'];
echo "Hash in DB: $hash\n";
echo "Verify TestSecurity123!: " . (password_verify('TestSecurity123!', $hash) ? 'VALID' : 'INVALID') . "\n";
echo "Verify 12345678: " . (password_verify('12345678', $hash) ? 'VALID' : 'INVALID') . "\n";

// 4. Users table structure
echo "\n=== USERS TABLE STRUCTURE ===\n";
$res = $conn->query("DESCRIBE users");
while ($r = $res->fetch_assoc()) echo $r['Field'] . " | " . $r['Type'] . " | " . $r['Null'] . " | " . $r['Default'] . "\n";

// 5. Check epayments2020
echo "\n=== epayments2020 DB ===\n";
$conn2 = @new mysqli('127.0.0.1', 'e2paymetntssecrets1234', $pass, 'epayments2020');
if (!$conn2->connect_error) {
    echo "ACCESSIBLE!\n";
    $res = $conn2->query("SHOW TABLES");
    while ($r = $res->fetch_array()) echo "  " . $r[0] . "\n";
    
    echo "\n=== epayments2020 Admin User ===\n";
    $res = $conn2->query("SELECT id,name,email,is_admin,password FROM users WHERE is_admin=1 LIMIT 5");
    if ($res) while ($r = $res->fetch_assoc()) echo json_encode($r) . "\n";
    
    echo "\n=== epayments2020 User 7 ===\n";
    $res = $conn2->query("SELECT * FROM users WHERE id=7 LIMIT 1");
    if ($res) {
        $r = $res->fetch_assoc();
        if ($r) foreach ($r as $k => $v) echo "$k: $v\n";
        else echo "No user with id=7\n";
    }
    
    $conn2->close();
} else {
    echo "NOT ACCESSIBLE: " . $conn2->connect_error . "\n";
}

// 6. Read e2payments web.php routes
echo "\n=== ROUTES ===\n";
$routes = @file_get_contents('/var/www/e2payments.explicador.co.mz/production/routes/web.php');
if ($routes) echo substr($routes, 0, 2000);
else echo "Cannot read routes\n";

// 7. Read auth config
echo "\n=== AUTH CONFIG ===\n";
$auth = @file_get_contents('/var/www/e2payments.explicador.co.mz/production/config/auth.php');
if ($auth) echo substr($auth, 0, 2000);

$conn->close();
?>