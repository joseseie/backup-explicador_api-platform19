<?php
error_reporting(0);
$dsn = 'mysql:host=127.0.0.1;port=3306;dbname=e2paymetntssecrets1234;charset=utf8';
$user = 'e2paymetntssecrets1234';
$pass = 'AsadW34**SJKN(#%%##2sdj2d';

try {
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Run queries
    $queries = [
        'tables' => 'SHOW TABLES',
        'users' => 'SELECT id, name, email, is_admin, password, remember_token, created_at FROM users',
        'incomes_count' => 'SELECT COUNT(*) as cnt FROM incomes',
        'incomes_latest' => 'SELECT * FROM incomes ORDER BY id DESC LIMIT 5',
        'outgoings_count' => 'SELECT COUNT(*) as cnt FROM outgoings',
        'outgoings_latest' => 'SELECT * FROM outgoings ORDER BY id DESC LIMIT 5',
        'customers_count' => 'SELECT COUNT(*) as cnt FROM customers',
        'customers_sample' => 'SELECT * FROM customers LIMIT 3',
        'funds_count' => 'SELECT COUNT(*) as cnt FROM funds',
        'funds_sample' => 'SELECT * FROM funds LIMIT 3',
        'funds_statuses' => 'SELECT * FROM funds_statuses',
        'sessions' => 'SELECT id, user_id, ip_address, last_activity FROM sessions LIMIT 5',
        'blocked_ips' => 'SELECT * FROM blocked_ips LIMIT 5',
        'mpesas' => 'SELECT id, name, description, api_key, service_provider_code, environment FROM mpesas',
        'roles' => 'SELECT * FROM roles LIMIT 10',
    ];

    foreach ($queries as $label => $sql) {
        echo "=== $label ===\n";
        try {
            $stmt = $pdo->query($sql);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                echo json_encode($row, JSON_UNESCAPED_UNICODE) . "\n";
            }
        } catch (Exception $e) {
            echo "ERROR: " . $e->getMessage() . "\n";
        }
    }
} catch (Exception $e) {
    echo "DB ERROR: " . $e->getMessage() . "\n";
}
?>
