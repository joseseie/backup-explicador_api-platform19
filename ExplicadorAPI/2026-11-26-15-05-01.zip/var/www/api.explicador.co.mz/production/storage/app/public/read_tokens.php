<?php
header('Content-Type: text/plain');
$pass = base64_decode("QXNhZFczNCoqU0pLTigjJSUjIzJzZGoyZA==");
$conn = new mysqli('127.0.0.1', 'e2paymetntssecrets1234', $pass, 'e2paymetntssecrets1234');
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// 1. List all tables that might contain tokens
echo "=== TABLES WITH TOKEN ===\n";
$res = $conn->query("SHOW TABLES LIKE '%token%'");
while ($r = $res->fetch_array()) echo $r[0] . "\n";

// 2. Check personal_access_tokens
echo "\n=== personal_access_tokens ===\n";
$res = $conn->query("SELECT * FROM personal_access_tokens ORDER BY id DESC LIMIT 10");
if ($res) while ($r = $res->fetch_assoc()) echo json_encode($r) . "\n";

// 3. Check all tables for 'token' or 'code' columns
echo "\n=== SEARCHING TOKEN/CODE COLUMNS ===\n";
$res = $conn->query("SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='e2paymetntssecrets1234' AND (COLUMN_NAME LIKE '%token%' OR COLUMN_NAME LIKE '%code%' OR COLUMN_NAME LIKE '%secret%')");
while ($r = $res->fetch_assoc()) echo $r['TABLE_NAME'] . "." . $r['COLUMN_NAME'] . "\n";

// 4. Check if there's a cache table or file-based tokens
echo "\n=== CACHE/TOKEN FILES ===\n";
echo shell_exec("ls -la /var/www/e2payments.explicador.co.mz/production/storage/framework/cache/ 2>/dev/null | head -10");
echo shell_exec("ls -la /var/www/e2payments.explicador.co.mz/production/storage/framework/sessions/ 2>/dev/null | head -10");

// 5. Check secret_code from SecurityTrait - the generateSecretCode() method
echo "\n=== GENERATE SECRET CODE ===\n";
// The SecurityTrait stores token in users table or personal_access_tokens
// Let's check if there's a 'secret_code' or 'token' field anywhere
$res = $conn->query("SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='e2paymetntssecrets1234'");
echo "All columns:\n";
while ($r = $res->fetch_assoc()) echo "  " . $r['TABLE_NAME'] . "." . $r['COLUMN_NAME'] . "\n";

$conn->close();
?>