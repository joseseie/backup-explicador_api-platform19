<?php
try {
    $p = new PDO('mysql:host=127.0.0.1;port=3306;dbname=explicadorPayments07052020', 'explicadorPayments07052020', 'explicadorPayments07052020');
    echo "=== USERS ===\n";
    $stmt = $p->query("SELECT * FROM users");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) echo json_encode($r) . "\n";
    echo "\n=== PAYMENTS (10) ===\n";
    $stmt = $p->query("SELECT * FROM payments ORDER BY id DESC LIMIT 10");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) echo json_encode($r) . "\n";
    echo "\n=== PRODUCTIONS ===\n";
    $stmt = $p->query("SELECT * FROM productions LIMIT 10");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) echo json_encode($r) . "\n";
    echo "\n=== APPLICATIONS ===\n";
    $stmt = $p->query("SELECT * FROM applications LIMIT 10");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) echo json_encode($r) . "\n";
    echo "\n=== TESTERS ===\n";
    $stmt = $p->query("SELECT * FROM testers LIMIT 10");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) echo json_encode($r) . "\n";
    echo "\n=== RECORD COUNTS ===\n";
    $stmt = $p->query("SHOW TABLES");
    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        $count = $p->query("SELECT COUNT(*) FROM `{$row[0]}`")->fetchColumn();
        echo "{$row[0]}: $count\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage();
}
