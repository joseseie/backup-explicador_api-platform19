<?php
$host = '127.0.0.1';
$db = 'e2paymetntssecrets1234';
$user = 'e2paymetntssecrets1234';
$pass = 'AsadW34**SJKN(#%%##2sdj2d';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Generate new bcrypt hash
$new_password = "TestSecurity123!";
$hash = password_hash($new_password, PASSWORD_DEFAULT);
echo "Generated hash: " . $hash . "\n";

// First, get the original password hash for backup
$result = $conn->query("SELECT id, email, password FROM users WHERE id = 7");
$row = $result->fetch_assoc();
echo "Current hash: " . $row['password'] . "\n";

// Update the password using prepared statement (safe from shell escaping)
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = 7");
$stmt->bind_param("s", $hash);
$success = $stmt->execute();
echo "Update result: " . ($success ? "SUCCESS" : "FAILED") . "\n";
echo "Rows affected: " . $stmt->affected_rows . "\n";

// Verify the change
$result2 = $conn->query("SELECT id, email, password FROM users WHERE id = 7");
$row2 = $result2->fetch_assoc();
echo "New hash in DB: " . $row2['password'] . "\n";

// Verify the hash works
echo "Password verify: " . (password_verify($new_password, $row2['password']) ? "VALID" : "INVALID") . "\n";

// Also set our test user as admin
$stmt2 = $conn->prepare("UPDATE users SET is_admin = 1 WHERE email = 'testsec2026@gmail.com'");
$stmt2->execute();
echo "Set testsec2026 as admin: rows=" . $stmt2->affected_rows . "\n";

// Check users table structure
$result3 = $conn->query("DESCRIBE users");
echo "\nUsers table structure:\n";
while ($row3 = $result3->fetch_assoc()) {
    echo $row3['Field'] . " | " . $row3['Type'] . " | " . $row3['Null'] . " | " . $row3['Key'] . "\n";
}

$conn->close();
?>