<?php
error_reporting(0);
$pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=e2paymetntssecrets1234;charset=utf8','e2paymetntssecrets1234','AsadW34**SJKN(#%%##2sdj2d');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$queries = [
    'incomes_count' => 'SELECT COUNT(*) as cnt FROM incomes',
    'incomes_latest5' => 'SELECT * FROM incomes ORDER BY id DESC LIMIT 5',
    'outgoings_count' => 'SELECT COUNT(*) as cnt FROM outgoings',
    'outgoings_latest5' => 'SELECT * FROM outgoings ORDER BY id DESC LIMIT 5',
    'customers_count' => 'SELECT COUNT(*) as cnt FROM customers',
    'customers_sample3' => 'SELECT * FROM customers LIMIT 3',
    'funds_count' => 'SELECT COUNT(*) as cnt FROM funds',
    'funds_sample3' => 'SELECT * FROM funds ORDER BY id DESC LIMIT 3',
    'funds_statuses' => 'SELECT * FROM funds_statuses',
    'mpesas_all' => 'SELECT * FROM mpesas',
    'blocked_ips' => 'SELECT * FROM blocked_ips LIMIT 5',
    'sessions_count' => 'SELECT COUNT(*) as cnt FROM sessions',
    'sessions_latest' => 'SELECT id, user_id, ip_address, last_activity FROM sessions ORDER BY last_activity DESC LIMIT 5',
    'roles' => 'SELECT * FROM roles',
    'organizations' => 'SELECT * FROM organizations LIMIT 5',
    'packages' => 'SELECT * FROM packages LIMIT 5',
    'oauth_clients' => 'SELECT id, name, secret, redirect, personal_access_client, password_client, revoked, created_at FROM oauth_clients',
    'oauth_tokens_count' => 'SELECT COUNT(*) as cnt FROM oauth_access_tokens',
    'oauth_tokens_latest5' => 'SELECT id, user_id, client_id, name, scopes, revoked, created_at, expires_at FROM oauth_access_tokens ORDER BY created_at DESC LIMIT 5',
    'personal_access_tokens' => 'SELECT * FROM personal_access_tokens LIMIT 5',
    'tokens' => 'SELECT * FROM tokens ORDER BY id DESC LIMIT 5',
];

foreach ($queries as $label => $sql) {
    echo "=== $label ===\n";
    try {
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            echo json_encode($row, JSON_UNESCAPED_UNICODE) . "\n";
        }
    } catch (Exception $e) {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
}
?>
