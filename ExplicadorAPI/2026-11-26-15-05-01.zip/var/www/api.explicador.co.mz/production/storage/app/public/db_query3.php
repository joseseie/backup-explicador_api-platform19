<?php
error_reporting(0);
$pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=e2paymetntssecrets1234;charset=utf8','e2paymetntssecrets1234','AsadW34**SJKN(#%%##2sdj2d');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$queries = [
    'outgoings_count' => 'SELECT COUNT(*) as cnt FROM outgoings',
    'outgoings_latest3' => 'SELECT id,title,amount,`to`,status,user_id,created_at FROM outgoings ORDER BY id DESC LIMIT 3',
    'customers_count' => 'SELECT COUNT(*) as cnt FROM customers',
    'customers_sample2' => 'SELECT * FROM customers LIMIT 2',
    'funds_count' => 'SELECT COUNT(*) as cnt FROM funds',
    'funds_latest2' => 'SELECT * FROM funds ORDER BY id DESC LIMIT 2',
    'funds_statuses' => 'SELECT * FROM funds_statuses',
    'mpesas_all' => 'SELECT id,name,description,api_key,service_provider_code,environment,created_at FROM mpesas',
    'blocked_ips_count' => 'SELECT COUNT(*) as cnt FROM blocked_ips',
    'sessions_count' => 'SELECT COUNT(*) as cnt FROM sessions',
    'roles' => 'SELECT * FROM roles',
    'organizations' => 'SELECT id,name,email,phone,created_at FROM organizations LIMIT 5',
    'oauth_clients' => 'SELECT id,name,redirect,personal_access_client,password_client,revoked FROM oauth_clients',
    'oauth_tokens_count' => 'SELECT COUNT(*) as cnt FROM oauth_access_tokens',
    'oauth_tokens_recent' => 'SELECT id,user_id,client_id,name,revoked,created_at,expires_at FROM oauth_access_tokens ORDER BY created_at DESC LIMIT 5',
    'tokens_recent' => 'SELECT * FROM tokens ORDER BY id DESC LIMIT 5',
];

foreach ($queries as $label => $sql) {
    echo "\n=== $label ===\n";
    try {
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            echo json_encode($row, JSON_UNESCAPED_UNICODE) . "\n";
        }
    } catch (Exception $e) {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
}
?>
