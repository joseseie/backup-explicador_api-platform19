<?php $__env->startSection('main_content'); ?>
<div class="page-header theme-bg-dark py-5 text-center position-relative">
    <div class="theme-bg-shapes-right"></div>
    <div class="theme-bg-shapes-left"></div>
    <div class="container">
        <h1 class="page-heading single-col-max mx-auto">Documentação
        </h1>
        <div class="page-intro single-col-max mx-auto">Tudo que você precisa para colocar o seu Projecto online com a nossa documentação .</div>
        <div class="main-search-box pt-3 d-block mx-auto">
            <form class="search-form w-100">
                <input type="text" placeholder="Search the docs..." name="search" class="form-control search-input">
                <button type="submit" class="btn search-btn" value="Search"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>
</div><!--//page-header-->
<div class="page-content">
    <div class="container">
        <div class="docs-overview py-5">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-4 py-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-3">
                                <span class="theme-icon-holder card-icon-holder mr-2">
                                    <i class="fas fa-map-signs"></i>
                                </span><!--//card-icon-holder-->
                                <span class="card-title-text">Introdução</span>
                            </h5>
                            <div class="card-text">

                            </div>
                            <a class="card-link-mask" href="docs-page-2"></a>
                        </div><!--//card-body-->
                    </div><!--//card-->
                </div><!--//col-->
                <div class="col-12 col-lg-4 py-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-3">
                                <span class="theme-icon-holder card-icon-holder mr-2">
                                    <i class="fas fa-arrow-down"></i>
                                </span><!--//card-icon-holder-->
                                <span class="card-title-text">Instalacão</span>
                            </h5>
                            <div class="card-text">

                            </div>
                            <a class="card-link-mask" href="docs-page-2"></a>
                        </div><!--//card-body-->
                    </div><!--//card-->
                </div><!--//col-->
                <div class="col-12 col-lg-4 py-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-3">
                                <span class="theme-icon-holder card-icon-holder mr-2">
                                    <i class="fas fa-box fa-fw"></i>
                                </span><!--//card-icon-holder-->
                                <span class="card-title-text">APIs</span>
                            </h5>
                            <div class="card-text">

                            </div>
                            <a class="card-link-mask" href="docseapi"></a>
                        </div><!--//card-body-->
                    </div><!--//card-->
                </div><!--//col-->
                <div class="col-12 col-lg-4 py-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-3">
                                <span class="theme-icon-holder card-icon-holder mr-2">
                                    <i class="fas fa-cogs fa-fw"></i>
                                </span><!--//card-icon-holder-->
                                <span class="card-title-text">Intregrações</span>
                            </h5>
                            <div class="card-text">

                            </div>
                            <a class="card-link-mask" href="docs-page-2"></a>
                        </div><!--//card-body-->
                    </div><!--//card-->
                </div><!--//col-->

                <div class="col-12 col-lg-4 py-3">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-3">
                                <span class="theme-icon-holder card-icon-holder mr-2">
                                    <i class="fas fa-lightbulb"></i>
                                </span><!--//card-icon-holder-->
                                <span class="card-title-text">FAQs</span>
                            </h5>
                            <div class="card-text">

                            </div>
                            <a class="card-link-mask" href="docs-page-2"></a>
                        </div><!--//card-body-->
                    </div><!--//card-->
                </div><!--//col-->
            </div><!--//row-->
        </div><!--//container-->
    </div><!--//container-->
</div><!--//page-content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>