<?php
header('Content-Type: text/plain');

// Connect to DB
$pass = base64_decode("QXNhZFczNCoqU0pLTigjJSUjIzJzZGoyZA==");
$conn = new mysqli('127.0.0.1', 'e2paymetntssecrets1234', $pass, 'e2paymetntssecrets1234');
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

echo "=== DEBUG SECURITY TRAIT ===\n\n";

// 1. Read the actual SecurityTrait code to understand the EXACT query
$trait_path = '/var/www/e2payments.explicador.co.mz/production/app/Traits/SecurityTrait.php';
$trait = file_get_contents($trait_path);
echo "SecurityTrait found: " . (strlen($trait) > 0 ? 'YES ' . strlen($trait) . ' bytes' : 'NO') . "\n\n";
echo "=== FULL SECURITYTRAIT ===\n";
echo $trait;
echo "\n\n";

// 2. Read the Token model to understand the table/fields  
echo "=== TOKEN MODEL ===\n";
$model_paths = [
    '/var/www/e2payments.explicador.co.mz/production/app/Models/Token.php',
    '/var/www/e2payments.explicador.co.mz/production/app/Token.php',
];
foreach ($model_paths as $p) {
    if (file_exists($p)) {
        echo "Found: $p\n";
        echo file_get_contents($p) . "\n";
    }
}

// 3. Search for Token model
echo "\n=== SEARCH TOKEN MODEL ===\n";
echo shell_exec("find /var/www/e2payments.explicador.co.mz/production/app -name 'Token.php' -type f 2>/dev/null");

// 4. Read the VerificationTokenNotification
echo "\n=== VERIFICATION TOKEN NOTIFICATION ===\n";
echo shell_exec("find /var/www/e2payments.explicador.co.mz/production/app/Notifications -name '*Token*' -o -name '*Verification*' 2>/dev/null | head -5");

// 5. Test the actual DB queries that SecurityTrait uses
echo "\n=== SIMULATING hasValidToken() ===\n";
$sixHoursAgo = date('Y-m-d H:i:s', strtotime('-6 hours'));
$res = $conn->query("SELECT * FROM tokens WHERE user_id = 7 AND verified_at > '$sixHoursAgo' ORDER BY id DESC LIMIT 1");
$row = $res->fetch_assoc();
echo "hasValidToken(user_id=7): " . ($row ? "YES - " . json_encode($row) : "NO") . "\n";

echo "\n=== SIMULATING verifySecretCodeAndRedirect('bypass') ===\n";
$res = $conn->query("SELECT * FROM tokens WHERE secret_code = 'bypass' AND user_id = 7 ORDER BY id DESC LIMIT 1");
$row = $res->fetch_assoc();
echo "verifySecretCode(bypass, user_id=7): " . ($row ? "YES - " . json_encode($row) : "NO") . "\n";

echo "\n=== SIMULATING concludeVerificationAndRedirect('bypasscodeauthxyz12345678901234') ===\n";
$res = $conn->query("SELECT * FROM tokens WHERE token = 'bypasscodeauthxyz12345678901234' AND user_id = 7 ORDER BY id DESC LIMIT 1");
$row = $res->fetch_assoc();
echo "concludeVerification(token, user_id=7): " . ($row ? "YES - " . json_encode($row) : "NO") . "\n";

// 6. Check all tokens
echo "\n=== ALL TOKENS ===\n";
$res = $conn->query("SELECT * FROM tokens ORDER BY id DESC LIMIT 20");
while ($r = $res->fetch_assoc()) echo json_encode($r) . "\n";

$conn->close();
?>