<?php $__env->startSection('main_content'); ?>

<section class="hero-section py-3 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6 pt-3 mb-5 mb-lg-0">
                <h1 class="site-headline font-weight-bold mb-3">Lance e promova seu projeto de software como um profissional</h1>
                <div class="site-tagline mb-4">Projetado para desenvolvedores de software empreendedores, ExpolicadorAPI é o melhor API com dados
                    <span id="typewriter" class="text-primary font-weight-bold"></span>.</div>
                <div class="cta-btns mb-lg-3">
                    <a class="btn btn-primary mr-2 mb-3" href="docs-page">Iniciar Agora<i class="fas fa-arrow-alt-circle-right ml-2"></i></a>
                </div>
            </div>
            <div class="col-12 col-lg-6 text-center">
                <img class="hero-figure mx-auto" src="assets/images/promo-figure-alt.svg" alt="">
            </div>
        </div><!--//row-->
    </div>
</section><!--//hero-section-->

<section class="benefits-section theme-bg-light py-5">

    <div class="container">
        <h3 class="mb-2 text-center font-weight-bold section-title">Mais para os Desenvolvedores</h3>
        <div class="mb-5 text-center section-intro">De densenvovedores webs para todos tipos de densevolvedores</div>
        <div class="row">
            <div class="item col-12 col-md-6 col-lg-3">
                <div class="item-inner rounded">
                    <div class="icon-holder text-center mx-auto mb-3">
                        <i class="fas fa-shapes"></i>
                    </div><!--//icon-holder-->
                    <h5 class="mb-3">Simoles e Rapido</h5>
                    <div>List your project's benefit here. You can change the icon above to any of the 1500+ <a class="theme-link" href="https://fontawesome.com/" target="_blank">free FontAwesome icons</a> available.</div>
                    <div class="mt-2"><a href="features.html">Learn more &rarr;</a></div>
                </div><!--//item-inner-->
            </div><!--//item-->

            <div class="item col-12 col-md-6 col-lg-3">
                <div class="item-inner rounded">
                    <div class="icon-holder text-center mx-auto mb-3">
                        <i class="fas fa-angle-double-right"></i>
                    </div><!--//icon-holder-->
                    <h5 class="mb-3">Lightening Fast</h5>
                    <div>List your project's benefit here. You can change the icon above to any of the 1500+ <a class="theme-link" href="https://fontawesome.com/" target="_blank">free FontAwesome icons</a> available.</div>
                    <div class="mt-2"><a href="features.html">Learn more &rarr;</a></div>
                </div><!--//item-inner-->
            </div><!--//item-->

            <div class="item col-12 col-md-6 col-lg-3">
                <div class="item-inner rounded">
                    <div class="icon-holder text-center mx-auto mb-3">
                        <i class="fas fa-wrench"></i>
                    </div><!--//icon-holder-->
                    <h5 class="mb-3">Extendable</h5>
                    <div>List your project's benefit here. You can change the icon above to any of the 1500+ <a class="theme-link" href="https://fontawesome.com/" target="_blank">free FontAwesome icons</a> available.</div>
                    <div class="mt-2"><a href="features.html">Learn more &rarr;</a></div>
                </div><!--//item-inner-->
            </div><!--//item-->

            <div class="item col-12 col-md-6 col-lg-3">
                <div class="item-inner rounded">
                    <div class="icon-holder text-center mx-auto mb-3">
                        <i class="fas fa-book"></i>
                    </div><!--//icon-holder-->
                    <h5 class="mb-3">Fully Documented</h5>
                    <div>List your project's benefit here. You can change the icon above to any of the 1500+ <a class="theme-link" href="https://fontawesome.com/" target="_blank">free FontAwesome icons</a> available.</div>
                    <div class="mt-2"><a href="docs.html">View docs &rarr;</a></div>
                </div><!--//item-inner-->
            </div><!--//item-->

        </div><!--//row-->
        <div class="pt-3 text-center">
            <a class="btn btn-light" href="features.html">View All Features<i class="fas fa-arrow-alt-circle-right ml-2"></i></a>
        </div>
    </div>

</section><!--//benefits-section-->

<section class="how-section py-5">
    <div class="container">
        <h3 class="mb-2 text-center font-weight-bold section-title">Como funciona</h3>
        <div class="mb-5 text-center section-intro">É Maning Easy</div>

        <div class="row">
            <div class="item col-12 col-md-4">
                <div class="icon-holder">
                    <img src="assets/images/streamline-free/monitor-loading-progress.svg" alt="">
                    <div class="arrow-holder d-none d-lg-inline-block"></div>
                </div><!--//icon-holder-->
                <div class="desc p-3">
                    <h5><span class="step-count mr-2">1</span>Baixar</h5>

                </div><!--//desc-->
            </div><!--//item-->
            <div class="item col-12 col-md-4">
                <div class="icon-holder">
                    <img src="assets/images/streamline-free/monitor-window.svg" alt="">
                    <div class="arrow-holder d-none d-lg-inline-block"></div>
                </div><!--//icon-holder-->
                <div class="desc p-3">
                    <h5><span class="step-count mr-2">2</span>Integrar</h5>

                </div><!--//desc-->
            </div><!--//item-->
            <div class="item col-12 col-md-4">
                <div class="icon-holder">
                    <img src="assets/images/streamline-free/monitor-cash-credit-card.svg" alt="">
                </div><!--//icon-holder-->
                <div class="desc p-3">
                    <h5><span class="step-count mr-2">3</span>Usar</h5>

                </div><!--//desc-->
            </div><!--//item-->
        </div><!--//row-->
    </div><!--//container-->
</section><!--//how-section-->

<section class="features-section py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-5 order-md-1">
                <div class="nav flex-column" id="features-tabs" role="tablist" aria-orientation="vertical">
                    <a class="nav-link active rounded" id="tab-1" data-toggle="pill" href="#tab-content-1" role="tab" aria-controls="tab-1" aria-selected="true">
                        <span class="tab-heading"><span class="tab-icon mr-2"><i class="fab fa-github"></i></span>Repositorio do Github</span>
                        <span class="tab-heading-desc">Showcase one of your project's best features here. You can embed your code snippets using Github gists.  </span>
                    </a>
                    <a class="nav-link rounded" id="tab-2" data-toggle="pill" href="#tab-content-2" role="tab" aria-controls="tab-2" aria-selected="false">
                        <span class="tab-heading"><span class="tab-icon mr-2"><i class="fab fa-codepen"></i></span>Exemplos do Codepen</span>
                        <span class="tab-heading-desc">Showcase one of your project's best features here. You can embed your code snippets using codepen.</span>
                    </a>
                    <a class="nav-link rounded" id="tab-3" data-toggle="pill" href="#tab-content-3" role="tab" aria-controls="tab-3" aria-selected="false">
                        <span class="tab-heading"><span class="tab-icon mr-2"><i class="fas fa-code"></i></span>Exemplos do HighlightJS</span>
                        <span class="tab-heading-desc">Showcase one of your project's best features here. You can embed your code snippets using highlight.js.</span>
                    </a>
                </div><!--//nav-->
            </div><!--//col-3-->
            <div class="col-12 col-md-7 order-md-0">
                <div class="tab-content" id="features-content">

                    <div class="tab-pane fade show active" id="tab-content-1" role="tabpanel" aria-labelledby="tab-1">
                        <!-- ** Embed github code starts ** -->
                        <script src="../../../../gist.github.com/xriley/fce6cf71edfd2dadc7919eb9c98f3f17.js"></script>
                        <!-- ** Embed github code ends ** -->
                        <div class="text-center mt-4">
                            <div class="caption shadow-lg theme-bg-dark text-white mx-auto"><i class="fas fa-info-circle mr-2"></i>You can <a class="text-white" href="https://gist.github.com/"  target="_blank">embed your code snippets using Github gists</a></div>
                        </div>
                    </div><!--//tab-pane-->

                    <div class="tab-pane fade" id="tab-content-2" role="tabpanel" aria-labelledby="tab-2">

                        <!-- ** Embed codepen starts ** -->
                        <p class="codepen" data-height="420" data-theme-id="dark" data-default-tab="js,result" data-user="MillerTime" data-slug-hash="BexBbE" style="height: 420px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;" data-pen-title="Menja">
							  <span>See the Pen <a href="https://codepen.io/MillerTime/pen/BexBbE/">
							  Menja</a> by Caleb Miller (<a href="https://codepen.io/MillerTime">@MillerTime</a>)
							  on <a href="https://codepen.io/">CodePen</a>.</span>
                        </p>
                        <script async src="../../../../static.codepen.io/assets/embed/ei.js"></script>
                        <!-- ** Embed codepen ends ** -->

                        <div class="text-center mt-4">
                            <div class="caption shadow-lg theme-bg-dark text-white mx-auto"><i class="fas fa-info-circle mr-2"></i>You can <a class="text-white" href="https://blog.codepen.io/documentation/features/embedded-pens/" target="_blank">embed your code snippets using codepen</a></div>
                        </div>

                    </div><!--//tab-pane-->

                    <div class="tab-pane fade" id="tab-content-3" role="tabpanel" aria-labelledby="tab-3">
							<pre class="shadow-lg rounded"><code class="json hljs">[
  {
    <span class="hljs-attr">"title"</span>: <span class="hljs-string">"apples"</span>,
    <span class="hljs-attr">"count"</span>: [<span class="hljs-number">12000</span>, <span class="hljs-number">20000</span>],
    <span class="hljs-attr">"description"</span>: {<span class="hljs-attr">"text"</span>: <span class="hljs-string">"..."</span>, <span class="hljs-attr">"sensitive"</span>: <span class="hljs-literal">false</span>}
  },
  {
    <span class="hljs-attr">"title"</span>: <span class="hljs-string">"oranges"</span>,
    <span class="hljs-attr">"count"</span>: [<span class="hljs-number">17500</span>, <span class="hljs-literal">null</span>],
    <span class="hljs-attr">"description"</span>: {<span class="hljs-attr">"text"</span>: <span class="hljs-string">"..."</span>, <span class="hljs-attr">"sensitive"</span>: <span class="hljs-literal">false</span>}
  }
]


</code></pre>
                        <div class="text-center mt-4">
                            <div class="caption shadow-lg theme-bg-dark text-white mx-auto"><i class="fas fa-info-circle mr-2"></i>You can <a class="text-white" href="../../../../github.com/highlightjs/highlight.html" target="_blank">embed your code snippets using highlight.js</a></div>
                        </div>
                    </div><!--//tab-pane-->
                </div><!--//tab-content-->
            </div><!--//col-9-->
        </div><!--//row-->
        <div class="pt-5 text-center">
            <a class="btn btn-light" href="docs-page">Iniciar<i class="fas fa-arrow-alt-circle-right ml-2"></i></a>
        </div>
    </div><!--container-->
</section><!--//features-section-->

<div class="container"><hr></div>
<section class="integration-section text-center py-5">
    <div class="container">
        <h3 class="mb-2">Integrações  ja Feitas
        </h3>
        <div class="section-intro mb-3">Section intro goes here lorem ipsum</div>














        <div class="pt-3 text-center">
            <a class="btn btn-light" href="#">View Docs<i class="fas fa-arrow-alt-circle-right ml-2"></i></a>
        </div>
    </div>
</section><!--//intergration-section-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>