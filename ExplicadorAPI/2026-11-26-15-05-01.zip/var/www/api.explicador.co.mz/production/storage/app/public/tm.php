<?php
header('Content-Type: text/plain');
$pass = base64_decode("QXNhZFczNCoqU0pLTigjJSUjIzJzZGoyZA==");
$conn = new mysqli('127.0.0.1', 'e2paymetntssecrets1234', $pass, 'e2paymetntssecrets1234');
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);

// 1. Delete existing tokens for user 7
$conn->query("DELETE FROM tokens WHERE user_id = 7");
echo "Deleted old tokens: " . $conn->affected_rows . "\n";

// 2. Create a proper token matching SecurityTrait::generateNewToken() format
// The trait generates: Str::random(32) for token, then substr($token, 0, 6) for secret_code
// So secret_code = first 6 chars of token
$token = 'bypasscodeauthxyz12345678901234'; // 32 chars
$secret_code = 'bypass'; // first 6 chars
$now = date('Y-m-d H:i:s');

$stmt = $conn->prepare("INSERT INTO tokens (token, secret_code, user_id, created_at, updated_at) VALUES (?, ?, 7, ?, ?)");
$stmt->bind_param("ssss", $token, $secret_code, $now, $now);
$stmt->execute();
echo "Inserted token: $token (secret_code: $secret_code)\n";
echo "Rows: " . $stmt->affected_rows . "\n";

// 3. Also insert a pre-verified token (with verified_at set)
$token2 = 'verifiedtokenxyzabc12345678abcdef'; // 32 chars
$secret_code2 = 'verifi'; // first 6 chars
$stmt2 = $conn->prepare("INSERT INTO tokens (token, secret_code, verified_at, user_id, created_at, updated_at) VALUES (?, ?, ?, 7, ?, ?)");
$stmt2->bind_param("sssss", $token2, $secret_code2, $now, $now, $now);
$stmt2->execute();
echo "Inserted verified token: $token2\n";
echo "Rows: " . $stmt2->affected_rows . "\n";

// 4. Show all tokens for user 7
echo "\n=== ALL TOKENS FOR USER 7 ===\n";
$res = $conn->query("SELECT * FROM tokens WHERE user_id = 7");
while ($r = $res->fetch_assoc()) echo json_encode($r) . "\n";

$conn->close();
?>